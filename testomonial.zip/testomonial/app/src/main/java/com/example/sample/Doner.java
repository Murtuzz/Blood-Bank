package com.example.sample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;

public class Doner extends AppCompatActivity {
    RadioGroup select;
    Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doner);
        select = (RadioGroup)findViewById(R.id.rgbutton);
        submit = (Button)findViewById(R.id.button2);
    }
}
