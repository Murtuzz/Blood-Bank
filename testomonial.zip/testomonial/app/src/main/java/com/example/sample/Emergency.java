package com.example.sample;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Spinner;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Emergency extends AppCompatActivity {
       @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency);}
    public void onBtnClicked(View v) {
        if(v.getId() == R.id.sendRequestButton)
                    MessageBox("We Will Contact You Shortly "); }
    public void MessageBox(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }}
