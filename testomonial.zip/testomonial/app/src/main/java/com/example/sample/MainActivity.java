package com.example.sample;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity {
/*    DatabaseHelper dB = new DatabaseHelper(getApplicationContext());
    SQLiteDatabase myDB = dB.getReadableDatabase();
    String query1 = "SELECT EMAIL_ID FROM Registration_Data WHERE Col_Name = 'COL_5'";
    Cursor cursor1 = myDB.rawQuery(query1,null);
    String query2 = "SELECT PASSWORD FROM Registration_Data WHERE Col_Name = 'COL_2'";
    Cursor cursor2 = myDB.rawQuery(query2,null);*/
    Button submit;
    int flag=0;
    EditText email,pass;
    RadioGroup gender;
    Spinner group;
    private Button registration,forgotPassword,login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        email   =   (EditText) findViewById(R.id.idText);
        pass   =   (EditText) findViewById(R.id.passwordText);
        registration = (Button)findViewById(R.id.registerButton);
        registration.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                registration();
            }});
        forgotPassword = (Button)findViewById(R.id.forgotPassword);
        forgotPassword.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                forgotPassword();
            }});
        login = (Button)findViewById(R.id.loginButton);
      /*  */
        frontPage();
    }

    public void registration(){
        Intent intent = new Intent(this,Registration.class);
        startActivity(intent);
    }
    public void forgotPassword(){
        Intent intent = new Intent(this,ForgotPassword.class);
        startActivity(intent);
    }
    public void frontPage(){
        login.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                String s =  email.getText().toString();
                String p = pass.getText().toString();
                /*while(cursor1!=null){
                    String col =cursor1.getString(cursor1.getColumnIndex("col"));
                    if(col==s){
                      int i =  cursor1.getColumnIndex("col");
                       String password = cursor2.getString(i);
                        if(password==p){
                            flag=1;
                            break; }}
                            cursor1.moveToNext();}*/ }});
        if(flag==1){
        Intent intent = new Intent(this,FrontPage.class);
        startActivity(intent);}
        else
            Toast.makeText(MainActivity.this, "Insert Valid Email And Password", Toast.LENGTH_LONG).show(); }}
