package com.example.sample;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.strictmode.SqliteObjectLeakedViolation;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.ArrayList;

import java.util.List;
import java.util.jar.Attributes;
public class Registration extends AppCompatActivity {
    DatabaseHelper myDB ;
    Button submit;
    EditText NAME,PASSWORD,CONFIRM_PASSWORD,MOBILE_NO,EMAIL_ID;
    //RadioGroup gender;
    //Spinner group;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        myDB = new DatabaseHelper(this);
        NAME   =   (EditText) findViewById(R.id.enterNameText);
        PASSWORD   =   (EditText) findViewById(R.id.editText3);
        CONFIRM_PASSWORD   =   (EditText) findViewById(R.id.editText4);
        //group   =   (Spinner) findViewById(R.id.bloodGroup);
        //gender  =   (RadioGroup) findViewById(R.id.radioGroup);
        MOBILE_NO  =   (EditText) findViewById(R.id.mobileNumber);
        EMAIL_ID   =   (EditText) findViewById(R.id.emailText);
        //age     =   (EditText) findViewById(R.id.editText8);
        submit  =   (Button)findViewById(R.id.registrationSubmit);
       AddData();
    }
    public void AddData(){
        submit.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDB.insertData(NAME.getText().toString(),
                                PASSWORD.getText().toString(),
                                CONFIRM_PASSWORD.getText().toString(),
                                MOBILE_NO.getText().toString(),
                                EMAIL_ID.getText().toString());
                        if(isInserted == true) {
                            Toast.makeText(Registration.this, "Data Insterted", Toast.LENGTH_LONG).show();
                          /*  submit.setOnClickListener(new View.OnClickListener(){
                                public void onClick(View v){
                                    mainActivity();
                                }
                            });*/ }
                            else
                                Toast.makeText(Registration.this, "Data not Insterted", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }
    public void mainActivity(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}
