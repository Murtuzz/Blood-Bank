package com.example.sample;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Registration.db";
    public static final String TABLE_NAME = "Registration_Data";
    public static final String COL_1 = "NAME";
    public static final String COL_2 = "PASSWORD";
    public static final String COL_3 = "CONFIRM_PASSWORD";
    //public static final String COL_4 = "BLOOD_GROUP";
    //public static final String COL_4 = "SEX";
    public static final String COL_4 = "MOBILE_NO.";
    public static final String COL_5 = "EMAIL_ID";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME +" (NAME TEXT NOT NULL, PASSWORD VARCHAR(20) NOT NULL, CONFIRMM_PASSWORD VARCHAR(20) NOT NULL, MOBILE_NO INTEGER primary key, EMAIL_ID VARCHAR(30))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }
    public boolean insertData(String NAME, String PASSWORD, String CONFIRM_PASSWORD, String MOBILE_NO, String EMAIL_ID){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1, NAME);
        contentValues.put(COL_2, PASSWORD);
        contentValues.put(COL_3, CONFIRM_PASSWORD);
        //contentValues.put(COL_4, BLOOD_GROUP);
        //contentValues.put(COL_4, SEX);
        contentValues.put(COL_4, MOBILE_NO);
        contentValues.put(COL_5, EMAIL_ID);
        long result = db.insert(TABLE_NAME,null, contentValues);
        if( result == -1)
            return false;
        else
            return true;
    }
}