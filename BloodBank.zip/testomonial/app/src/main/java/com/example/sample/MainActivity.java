package com.example.sample;
import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity {
    private Button registration,forgotPassword,login;
    EditText email,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        email   =   (EditText) findViewById(R.id.idText);
        pass   =   (EditText) findViewById(R.id.passwordText);
        registration = (Button)findViewById(R.id.registerButton);
        registration.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                registration();
            }});
        forgotPassword = (Button)findViewById(R.id.forgotPassword);
        forgotPassword.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                forgotPassword();
            }});
        login = (Button)findViewById(R.id.loginButton);
        login.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                frontPage();
            }});

    }
    public void registration(){
        Intent intent = new Intent(this,Registration.class);
        startActivity(intent);
    }
    public void forgotPassword(){
        Intent intent = new Intent(this,ForgotPassword.class);
        startActivity(intent);
    }
    public void frontPage(){
        Intent intent = new Intent(this,FrontPage.class);
        startActivity(intent);
    }
}
