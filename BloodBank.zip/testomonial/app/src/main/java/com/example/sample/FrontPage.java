package com.example.sample;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
public class FrontPage extends AppCompatActivity {

    private Button doner,needy,emergency;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_front_page);
        doner= (Button)findViewById(R.id.beADoner);
        doner.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                doner();
            }});
        needy = (Button)findViewById(R.id.needBlood);
        needy.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                needy();
            }});
        emergency = (Button)findViewById(R.id.button3);
        emergency.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                emergency();
            }}); }
    public void doner(){
        Intent intent = new Intent(this,Doner.class);
        startActivity(intent);
    }
    public void needy(){
        Intent intent = new Intent(this,Needy.class);
        startActivity(intent);
    }
    public void emergency(){
        Intent intent = new Intent(this,Emergency.class);
        startActivity(intent);
    }
}
